import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
      ArrayList<EProizvodi>lista = new ArrayList<EProizvodi>();
      
      Telefoni t1 = new Telefoni("Telefonski uredjaj","TE324A",600,"Iphone",4);
	  TV t2 = new TV("Televizor","RV433S",940,67);
	  Racunari r1 = new Racunari("Racunar","RA242L",1200,"Ryzen 5",32);
	  
	  lista.add(t1);
	  lista.add(t2);
	  lista.add(r1);
	  
	  System.out.println("Sadrzaj Elektricnih proizvoda: ");
	  for(EProizvodi e:lista) {
		  System.out.println(e);
	  }
      
      for(EProizvodi e:lista) {
      System.out.println(e.maloProdajnaCijena());	   
	}

  }
}
