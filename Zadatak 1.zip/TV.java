
public class TV extends EProizvodi {
       private double velicinaEkrana;

	   public double getVelicinaEkrana() {
		   return velicinaEkrana;
	   }

	   public void setVelicinaEkrana(double velicinaEkrana) {
		   this.setVelicinaEkrana(velicinaEkrana);
	   }

	   public TV(String opisProizvoda, String sifreProizvoda, double uvoznaCijenaProizvoda, double velicinaEkrana) {
		super(opisProizvoda, sifreProizvoda, uvoznaCijenaProizvoda);
		this.velicinaEkrana = velicinaEkrana;
	   }

	   @Override
	   public String toString() {
		return "'klasa': 'TV' 'OpisProizvoda':" + getOpisProizvoda() + ",\n 'SifreProizvoda':" + getSifreProizvoda() 
				+ ",\n 'UvoznaCijenaProizvoda':" + getUvoznaCijenaProizvoda() + ",\n 'getVelicinaEkrana':" + getVelicinaEkrana() + "}";
	   }
	      public double maloProdajnaCijena() {
	    	  double cijena = super.maloProdajnaCijena();
	          if (velicinaEkrana > 65.0) {
	              cijena *= 1.10; 
	          }else {
	        	  cijena = uvoznaCijenaProizvoda;
	          }
	          return cijena;
	      }
       
}
