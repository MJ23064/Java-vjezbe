
public class Racunari extends EProizvodi {
    private String procesor;
    private int memorija;
	public String getProcesor() {
		return procesor;
	}
	public void setProcesor(String procesor) {
		this.procesor = procesor;
	}
	public int getMemorija() {
		return memorija;
	}
	public void setMemorija(int memorija) {
		this.memorija = memorija;
	}
	public Racunari(String opisProizvoda, String sifreProizvoda, double uvoznaCijenaProizvoda, String procesor,
			int memorija) {
		super(opisProizvoda, sifreProizvoda, uvoznaCijenaProizvoda);
		this.setProcesor(procesor);
		this.setMemorija(memorija);
	}
	@Override
	public String toString() {
		return "{ 'klasa': 'Racunari 'OpisProizvoda':" + getOpisProizvoda() + ",\n 'SifreProizvoda':" + getSifreProizvoda() 
				+ ",\n 'UvoznaCijenaProizvoda':" + getUvoznaCijenaProizvoda() + " 'Procesor':" + getProcesor() + ",\n 'Memorija':" + getMemorija() + "}";
	}
	public double maloprodajnaCijena() {
		double cijena = super.maloProdajnaCijena();
		cijena =cijena * 1.05;
	 return cijena;	
	}
    
    
    
}
