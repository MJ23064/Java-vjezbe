
public class Telefoni extends EProizvodi {
      private String operativniSistem;
      private double velicinaEkrana;
	  public String getOperativniSistem() {
		  return operativniSistem;
	  }
	  public void setOperativniSistem(String operativniSistem) {
		  this.operativniSistem = operativniSistem;
	  }
	  public double getVelicinaEkrana() {
		  return velicinaEkrana;
	  }
	  public void setVelicinaEkrana(double velicinaEkrana) {
		  this.velicinaEkrana = velicinaEkrana;
	  }
	  public Telefoni(String opisProizvoda, String sifreProizvoda, double uvoznaCijenaProizvoda, String operativniSistem,
			double velicinaEkrana) {
		super(opisProizvoda, sifreProizvoda, uvoznaCijenaProizvoda);
		this.setOperativniSistem(operativniSistem);
		this.setVelicinaEkrana(velicinaEkrana);
	  }
	  @Override
	  public String toString() {
		return "{ 'klasa': 'Telefoni' 'OpisProizvoda':" + getOpisProizvoda() + ",\n 'SifreProizvoda':" + getSifreProizvoda()
				+ ",\n 'UvoznaCijenaProizvoda':" + getUvoznaCijenaProizvoda() + ",\n 'OperativniSistem':" + getOperativniSistem() + ",\n 'VelicinaEkrana':"
				+ getVelicinaEkrana() + "}";
	  }
      public double maloProdajnaCijena() {
    	  double cijena = super.maloProdajnaCijena();
          if (velicinaEkrana > 6.0) {
              cijena *= 1.03; 
          }else {
        	  cijena = uvoznaCijenaProizvoda;
          }
          return cijena;
      }
}
