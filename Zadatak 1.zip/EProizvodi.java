
public class EProizvodi {

	protected String opisProizvoda;
	protected String sifreProizvoda;
	protected double uvoznaCijenaProizvoda;
	public String getOpisProizvoda() {
		return opisProizvoda;
	}
	public void setOpisProizvoda(String opisProizvoda) {
		this.opisProizvoda = opisProizvoda;
	}
	public String getSifreProizvoda() {
		return sifreProizvoda;
	}
	public void setSifreProizvoda(String sifreProizvoda) {
		this.sifreProizvoda = sifreProizvoda;
	}
	public double getUvoznaCijenaProizvoda() {
		return uvoznaCijenaProizvoda;
	}
	public void setUvoznaCijenaProizvoda(double uvoznaCijenaProizvoda) {
		this.uvoznaCijenaProizvoda = uvoznaCijenaProizvoda;
	}
	public EProizvodi(String opisProizvoda, String sifreProizvoda, double uvoznaCijenaProizvoda) {
		super();
		this.setOpisProizvoda(opisProizvoda);
		this.setSifreProizvoda(sifreProizvoda);
		this.setUvoznaCijenaProizvoda(uvoznaCijenaProizvoda);
	}
	@Override
	public String toString() {
		return "{ 'klasa' : 'EProizvodi' 'OpisProizvoda':" + getOpisProizvoda() + ",\n 'SifreProizvoda':" + getSifreProizvoda()
				+ ",\n 'UvoznaCijenaProizvoda':" + getUvoznaCijenaProizvoda() + "}";
	}
	public double maloProdajnaCijena() {
		return uvoznaCijenaProizvoda;
	}
	
}
