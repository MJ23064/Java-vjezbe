import java.util.ArrayList;
public class test {

	public static void main(String[] args) {
	        Restoran r = new Restoran("Fast Food King", "Glavna 5", "123456789");
	        konobar k1 = new konobar(24, "Ismet", "Marković", 5.5, 5, 600);
	        konobar k2 = new konobar(33, "Selim", "Purisic", 5.5, 3, 500);
	        kuvar kuvar = new kuvar(15, "Jelena", "Bojovic", 5, 6,170);
	        menadzer m1 = new menadzer(20, "Nizo", "Pjetrovic", 8.0, 5, 250, 1300);
	        konobar k3 = new konobar(18, "Tarik", "Hadzhimushaj", 6, 3, 573); 
	        
	        r.dodajZaposlenog(k1);
	        r.dodajZaposlenog(k2);
	        r.dodajZaposlenog(kuvar);
	        r.dodajZaposlenog(m1);
	        r.dodajZaposlenog(k3);

	        ArrayList<Zaposleni> radniciJutarnja = new ArrayList<>();
	        radniciJutarnja.add(k1);
	        radniciJutarnja.add(kuvar);
	        Smjena jutarnjaSmjena = new Smjena("09-11-2025", "08:00", "16:00", "jutarnja", radniciJutarnja);

	        ArrayList<Zaposleni> radniciPopodnevna = new ArrayList<>();
	        radniciPopodnevna.add(k2);
	        radniciPopodnevna.add(m1);
	        Smjena popodnevnaSmjena = new Smjena("09-11-2025", "12:00", "20:00", "popodnevna", radniciPopodnevna);

	        ArrayList<Zaposleni> radniciNocna = new ArrayList<>();
	        radniciNocna.add(k3);
	        radniciNocna.add(kuvar);
	        Smjena nocnaSmjena = new Smjena("10-11-2025", "22:00", "06:00", "noćna", radniciNocna);

	        r.dodajSmjenu(jutarnjaSmjena);
	        r.dodajSmjenu(popodnevnaSmjena);
	        r.dodajSmjenu(nocnaSmjena);

	        r.izracunajSateIzSmjena();

	        r.ObracunPlata(11, 2025);
	        
	        r.ispisiIstorijuObracuna();
	    }
	}


