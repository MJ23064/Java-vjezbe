
public class konobar extends Zaposleni {
     private double brojPrekovremenihSati;

	 public double getBrojPrekovremenihSati() {
		 return brojPrekovremenihSati;
	 }

	 public void setBrojPrekovremenihSati(double brojPrekovremenihSati) {
		 this.brojPrekovremenihSati = brojPrekovremenihSati;
	 }

	 public konobar(int iD, String ime, String prezime, double satnica, double ukupanBrojSati,
			double brojPrekovremenihSati) {
		super(iD, ime, prezime, satnica, ukupanBrojSati);
		this.brojPrekovremenihSati = brojPrekovremenihSati;
	 }

	 @Override
	 public String toString() {
		return "konobar [brojPrekovremenihSati=" + brojPrekovremenihSati + "]";
	 }
     public double plataZaposlenih() {
    	 double sedmicnaPlata = ukupanBrojSati * satnica + brojPrekovremenihSati * satnica * 1.2;
         return sedmicnaPlata * 4;
    	 
     }
}
