
public class kuvar extends Zaposleni {
     private double fiksniIznos;

	 public double getFiksniIznos() {
		 return fiksniIznos;
	 }

	 public void setFiksniIznos(double fiksniIznos) {
		 this.fiksniIznos = fiksniIznos;
	 }

	 public kuvar(int iD, String ime, String prezime, double satnica, double ukupanBrojSati, double fiksniIznos) {
		super(iD, ime, prezime, satnica, ukupanBrojSati);
		this.fiksniIznos = fiksniIznos;
	 }

	 @Override
	 public String toString() {
		return "kuvar [fiksniIznos=" + fiksniIznos + "]";
	 }
     public double plataZaposlenih() {
         return fiksniIznos + 4 * ukupanBrojSati * satnica;
     }
}
