
public class menadzer extends Zaposleni {
     private double osnovica;
     private double bonus;
	
     public double getOsnovica() {
		 return osnovica;
	 }
	 public void setOsnovica(double osnovica) {
		 this.osnovica = osnovica;
	 }
	 public double getBonus() {
		 return bonus;
	 }
	 public void setBonus(double bonus) {
		 this.bonus = bonus;
	 }
	 public menadzer(int iD, String ime, String prezime, double satnica, double ukupanBrojSati, double osnovica,
			double bonus) {
		super(iD, ime, prezime, satnica, ukupanBrojSati);
		this.osnovica = osnovica;
		this.bonus = bonus;
	 }
	 @Override
	 public String toString() {
		return "menadzer [osnovica=" + osnovica + ", bonus=" + bonus + "]";
	 }
     public double plataZaposlenih() {
    	 return osnovica + 4 * ukupanBrojSati * satnica + bonus;
     }
}
