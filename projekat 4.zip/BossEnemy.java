
class BossEnemy extends Enemy {
	   
	public BossEnemy(double x, double y, Collidable collider, int dmg, int hp) {
	        super(x, y, collider, dmg, hp);
	    }

	    
	    public int getEffectiveDamage() {
	        return damage * 2;
	    }
	    
	    public String toString() {
	        return "Boss" + super.toString();
	    }
}
