
public interface attacker {
	 int getEffectiveDamage();
}
