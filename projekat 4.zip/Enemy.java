
public class Enemy extends GameObject implements attacker {
	   protected int damage;
	    protected int health;

	    public Enemy(double x, double y, Collidable collider, int damage, int health) {
	        super(x, y, collider);
	        setDamage(damage);
	        setHealth(health);
	    }

	    public void setDamage(int dmg) {
	        if (dmg < 0 || dmg > 100) throw new IllegalArgumentException("DMG mora biti 0-100");
	        this.damage = dmg;
	    }
	    public void setHealth(int h) {
	        if (h < 0 || h > 100) throw new IllegalArgumentException("HP mora biti 0-100");
	        this.health = h;
	    }

	   
	    public int getEffectiveDamage() {
	        return damage;
	    }

	    
	    public String getDisplayName() {
	        return "Enemy DMG=" + damage + " HP=" + health;
	    }
	    
	    public String toString() {
	        return getDisplayName() + " Pos(" + x + "," + y + ") " + collider;
	    }
}
