
class MeleeEnemy extends Enemy {
    
	public MeleeEnemy(double x, double y, Collidable collider, int dmg, int hp) {
        super(x, y, collider, dmg, hp);
    }

    public String toString() {
        return "Melee" + super.toString();
    }
}
