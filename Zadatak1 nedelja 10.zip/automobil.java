
public class automobil extends Vozilo implements Ekonomican{
	    public automobil(int id, double maxBrzina) {
	        super(id, maxBrzina);
	    }
	    public double izracunajVrijemeDostave(double udaljenostKm) {
	        return udaljenostKm / maxBrzina;
	    }
		public double potrosnjaPoKm() {
			return 0;
		}
	}


