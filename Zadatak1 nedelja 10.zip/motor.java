
public class motor extends Vozilo implements Ekonomican{
	   
	    public motor(int id, double maxBrzina) {
	        super(id, maxBrzina);
	    }

	    
	    public double izracunajVrijemeDostave(double udaljenostKm) {
	        return udaljenostKm / maxBrzina;
	    }

		public double potrosnjaPoKm() {
			return 0.05;
		}
	}




