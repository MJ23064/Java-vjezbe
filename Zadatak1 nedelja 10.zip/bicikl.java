
public class bicikl extends Vozilo implements Ekonomican {
       
	    public bicikl(int id, double maxBrzina) {
	        super(id, maxBrzina);
	    }
	    
	    public double izracunajVrijemeDostave(double udaljenostKm) {
	        return udaljenostKm / maxBrzina;
	    }

	   
	    public double potrosnjaPoKm() {
	        return 0; 
	    }

	}


	



