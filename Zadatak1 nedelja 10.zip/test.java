import java.util.ArrayList;
public class test {

	    public static void main(String[] args) {

	        ArrayList<Vozilo> vozila = new ArrayList<>();
	        vozila.add(new bicikl(1, 20));
	        vozila.add(new motor(2, 60));
	        vozila.add(new automobil(3, 100));

	        double udaljenost = 10;


	        for (Vozilo v : vozila) {
	            v.info();

	            double vrijeme = v.izracunajVrijemeDostave(udaljenost);
	            System.out.println("Vrijeme dostave: " + vrijeme + " h");

	            double potrosnja = v.izracunajPotrosnju(udaljenost);
	            if (potrosnja >= 0) {
	                System.out.println("Ukupna potrošnja: " + potrosnja + " jedinica");
	            }

	            System.out.println();
	        }


	        for (Vozilo v : vozila) {
	            double vrijeme = v.izracunajVrijemeDostave(udaljenost);
	            double potrosnja = v.izracunajPotrosnju(udaljenost);

	            System.out.print("Vozilo " + v.id + ": ");
	            System.out.print("vrijeme = " + vrijeme + " h");

	            if (potrosnja >= 0) {
	                System.out.print(", potrošnja = " + potrosnja);
	            }

	            System.out.println();
	        }
	    }
	}



