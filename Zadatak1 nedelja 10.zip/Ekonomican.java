
public interface Ekonomican {
     double potrosnjaPoKm();

}
